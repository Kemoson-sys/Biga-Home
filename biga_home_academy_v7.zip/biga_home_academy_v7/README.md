# BIGA HOME ACADEMY V7 — Google Forms + Google Sheets, no SQL

A Flask-based learning platform using Python, HTML, CSS and JavaScript. **No SQL database or SQL dependency is used.** The application stores operational data in a local JSON file (`data/academy.json`) and can optionally mirror selected events into Google Sheets through Google Apps Script. Google Forms can be linked for registration enquiries, enrollment, assignments and contact/feedback.

## Included
- Blue, white and orange responsive academy interface.
- Course catalogue: cybersecurity, telecommunications, networking, Microsoft, IT tutorials and programming.
- Local student registration/login with password hashing (not Google Forms passwords).
- Student profile edits and profile-picture upload/removal.
- Course enrollment, lessons, lesson completion tracking and dashboard progress.
- Instructor/admin role-protected lesson and assignment creation.
- Assignment submissions, instructor grading and feedback.
- Instructor Content Manager for uploading lecture notes and videos, assigning them to courses, publishing resources, and removing materials.
- Supported notes: PDF, DOC, DOCX, PPT, PPTX, TXT, ZIP and CSV. Supported video files: MP4, WEBM and MOV.
- Students enrolled in a course can access its published materials from the course page and lesson pages.
- Optional Google Form links with setup guide.
- Optional Google Sheets event mirror using Apps Script.
- Health endpoint at `/health`.

## Upload lecture notes and videos
1. Sign in with an administrator or instructor account.
2. Open **Manage academy** from the top navigation.
3. In **Upload lecture notes or video**, choose a title, course and material type.
4. Either select a supported file or paste an HTTPS YouTube/Google Drive link.
5. Click **Publish learning material**. Students who are enrolled in that course can find the resources on its course page and lesson pages.

For large videos, prefer YouTube or Google Drive rather than direct uploads. The Flask request limit is set to 250 MB, but your hosting provider may impose a lower limit. The application is a prototype; configure HTTPS, malware scanning, backups, and a production upload/storage strategy before accepting public uploads.

## Run locally
1. Install Python 3.10+.
2. Extract the ZIP and open a terminal in this folder.
3. Create a virtual environment (recommended): `python -m venv .venv`; activate it.
4. Install packages: `pip install -r requirements.txt`.
5. Copy `.env.example` to `.env` and set a strong `SECRET_KEY`.
6. Run `python app.py` and visit `http://127.0.0.1:5000`.

No database setup or SQL migration is needed. The app creates `data/academy.json` automatically. Back up this file and the `static/uploads` folder regularly. JSON storage is suitable for a prototype/small deployment only; it is not safe for concurrent multi-worker production hosting. For a larger academy, use a proper non-SQL backend such as Google Firestore or a well-designed API.

## Admin account
Register an account, stop the app, then edit `data/academy.json` and change that user's `role` from `student` to `admin`. Restart the app. Keep the JSON file private and back it up before editing. Never share the password hash or file publicly.

## Google Forms
Read [`google_forms_setup.md`](google_forms_setup.md). The project includes blank placeholders because Forms must be created in your Google account. Set the published responder URLs in `.env`:
- `GOOGLE_FORM_REGISTRATION_URL`
- `GOOGLE_FORM_ENROLLMENT_URL`
- `GOOGLE_FORM_ASSIGNMENT_URL`
- `GOOGLE_FORM_CONTACT_URL`

Important: Google Forms responses are stored in the linked Google Sheets, but are not automatically imported into the app. Do not collect passwords in Google Forms. If you need form submissions to create accounts or sync grades, that requires a separate authenticated integration.

## Google Sheets event mirror (optional)
Follow [`google_apps_script/README.md`](google_apps_script/README.md), deploy the Apps Script Web App and set `GOOGLE_APPS_SCRIPT_WEB_APP_URL` and `GOOGLE_APPS_SCRIPT_SHARED_SECRET` in `.env`. The webhook mirrors selected events (registration, enrollment, lesson completion, submissions, grading, publishing) into an `Academy Events` sheet. It is one-way event logging, not full two-way data sync. Do not put passwords, password hashes, profile images or sensitive data into Sheets.

## Production notes
- Change `SECRET_KEY`; use HTTPS and a production WSGI server.
- Keep `.env`, `data/academy.json`, and uploads out of public source control.
- Set upload limits and review file handling before accepting public uploads.
- The certificate verification page is a placeholder foundation; certificate issuance workflow should be added before presenting certificates as officially valid.
- Validate Google Form URLs before enabling them. Leave blank to use the built-in workflow.
