import os, json, uuid, hmac, hashlib, secrets, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from PIL import Image, UnidentifiedImageError

load_dotenv()
app=Flask(__name__)
app.secret_key=os.getenv('SECRET_KEY') or 'dev-only-change-this-secret-key'
# Upload ceiling for notes and video lessons; tune for your hosting provider.
app.config['MAX_CONTENT_LENGTH']=250*1024*1024
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; DATA.mkdir(exist_ok=True)
UPLOADS=ROOT/'static'/'uploads'; UPLOADS.mkdir(parents=True,exist_ok=True)
PROFILE_DIR=UPLOADS/'profiles'; PROFILE_DIR.mkdir(exist_ok=True)
MATERIAL_DIR=UPLOADS/'materials'; MATERIAL_DIR.mkdir(exist_ok=True)
STORE=DATA/'academy.json'
GOOGLE_FORMS={
 'registration': os.getenv('GOOGLE_FORM_REGISTRATION_URL',''),
 'enrollment': os.getenv('GOOGLE_FORM_ENROLLMENT_URL',''),
 'assignment': os.getenv('GOOGLE_FORM_ASSIGNMENT_URL',''),
 'contact': os.getenv('GOOGLE_FORM_CONTACT_URL',''),
}
SHEETS_WEBHOOK=os.getenv('GOOGLE_APPS_SCRIPT_WEB_APP_URL','').strip()
COURSES=[
 {'id':'cybersecurity-fundamentals','title':'Cybersecurity Fundamentals','category':'Cybersecurity','level':'Beginner','duration':'6 weeks','icon':'🛡️','description':'Learn security principles, threats, risk management, and practical defensive techniques.','modules':['Security foundations','Threats and vulnerabilities','Network defense basics','Incident response']},
 {'id':'telecommunications-essentials','title':'Telecommunications Essentials','category':'Telecommunication','level':'Beginner–Intermediate','duration':'8 weeks','icon':'📡','description':'Understand mobile networks, radio access, transmission, fiber optics, and telecom KPIs.','modules':['Telecom fundamentals','Radio access networks','Fiber and microwave transmission','Network performance KPIs']},
 {'id':'computer-networking-ccna','title':'Computer Networking & CCNA Prep','category':'Networking','level':'Beginner','duration':'10 weeks','icon':'🌐','description':'Build practical networking knowledge covering IP addressing, routing, switching, and troubleshooting.','modules':['OSI and TCP/IP models','IPv4 and subnetting','Switching and VLANs','Routing and troubleshooting']},
 {'id':'microsoft-office','title':'Microsoft Office Productivity','category':'Microsoft','level':'Beginner','duration':'4 weeks','icon':'🧩','description':'Use Word, Excel, PowerPoint, and essential productivity tools with confidence.','modules':['Microsoft Word','Excel formulas and charts','PowerPoint presentations','Files and collaboration']},
 {'id':'it-support','title':'IT Support & Computer Basics','category':'IT Tutorials','level':'Beginner','duration':'5 weeks','icon':'💻','description':'Learn computer hardware, operating systems, help-desk practice, and common troubleshooting.','modules':['Computer hardware','Windows fundamentals','Troubleshooting methods','IT support practice']},
 {'id':'python-programming','title':'Python Programming','category':'Programming','level':'Beginner','duration':'8 weeks','icon':'🐍','description':'Start programming with Python through clear lessons, exercises, and small projects.','modules':['Variables and data types','Conditions and loops','Functions and modules','Build a small project']},
 {'id':'web-development','title':'Web Development: HTML, CSS & JavaScript','category':'Programming','level':'Beginner','duration':'8 weeks','icon':'🧑‍💻','description':'Create responsive websites and add interactive features using core web technologies.','modules':['HTML page structure','CSS layouts and responsive design','JavaScript interactions','Build a portfolio website']},
 {'id':'linux-network-admin','title':'Linux & Network Administration','category':'Networking','level':'Intermediate','duration':'6 weeks','icon':'⚙️','description':'Practice Linux commands, user permissions, services, and network administration basics.','modules':['Linux command line','Users and permissions','Services and logs','Network administration']},
]
def now(): return datetime.now(timezone.utc).isoformat()
def empty_store(): return {'users':[],'enrollments':[],'lessons':[],'progress':[],'assignments':[],'submissions':[],'quizzes':[],'quiz_results':[],'materials':[],'certificates':[],'events':[]}
def load_store():
 if not STORE.exists():
  data=empty_store(); save_store(data); return data
 try:
  data=json.loads(STORE.read_text(encoding='utf-8'))
  for k,v in empty_store().items(): data.setdefault(k,v)
  return data
 except (json.JSONDecodeError,OSError):
  raise RuntimeError('data/academy.json is unreadable. Restore it from backup before continuing.')
def save_store(data):
 tmp=STORE.with_suffix('.tmp'); tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(STORE)
def current_user():
 if not session.get('user_id'): return None
 return next((u for u in load_store()['users'] if u['id']==session['user_id']),None)
def send_to_sheets(event, payload):
 """Optional Apps Script webhook. Local JSON remains the source of truth if not configured."""
 if not SHEETS_WEBHOOK: return False
 body=json.dumps({'secret':os.getenv('GOOGLE_APPS_SCRIPT_SHARED_SECRET',''),'event':event,'payload':payload,'created_at':now()}).encode()
 req=urllib.request.Request(SHEETS_WEBHOOK,data=body,headers={'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=8) as response: return 200 <= response.status < 300
 except (urllib.error.URLError,TimeoutError) as exc:
  app.logger.warning('Google Sheets webhook failed: %s',exc); return False
def log_event(event,payload):
 data=load_store(); data['events'].append({'event':event,'payload':payload,'created_at':now()}); save_store(data)
 send_to_sheets(event,payload)
def login_required(fn):
 @wraps(fn)
 def wrap(*a,**kw):
  if not current_user(): flash('Please sign in to continue.','info'); return redirect(url_for('login',next=request.path))
  return fn(*a,**kw)
 return wrap
def role_required(*roles):
 def dec(fn):
  @wraps(fn)
  def wrap(*a,**kw):
   u=current_user()
   if not u: flash('Please sign in to continue.','info'); return redirect(url_for('login'))
   if u.get('role') not in roles: abort(403)
   return fn(*a,**kw)
  return wrap
 return dec
def get_course(cid): return next((c for c in COURSES if c['id']==cid),None)
def enrolled(user_id,cid): return any(e['user_id']==user_id and e['course_id']==cid for e in load_store()['enrollments'])
def safe_file_name(name): return secure_filename(name)[:100]
ALLOWED_NOTE_EXTENSIONS={'.pdf','.doc','.docx','.ppt','.pptx','.txt','.zip','.csv'}
ALLOWED_VIDEO_EXTENSIONS={'.mp4','.webm','.mov'}
def can_access_course_material(user, course_id):
 return bool(user and (user.get('role') in ('admin','instructor') or enrolled(user['id'],course_id)))
def is_allowed_material(filename, kind):
 ext=Path(filename).suffix.lower()
 return ext in (ALLOWED_VIDEO_EXTENSIONS if kind=='video' else ALLOWED_NOTE_EXTENSIONS)
@app.context_processor
def inject_globals(): return {'academy_name':'BIGA HOME ACADEMY','google_forms':GOOGLE_FORMS,'current_user_obj':current_user()}
@app.route('/')
def index():
 category=request.args.get('category','All'); q=request.args.get('q','').lower().strip()
 courses=[c for c in COURSES if (category=='All' or c['category']==category) and (not q or q in c['title'].lower() or q in c['description'].lower() or q in c['category'].lower())]
 return render_template('index.html',courses=courses,categories=sorted({c['category'] for c in COURSES}))
@app.route('/register',methods=['GET','POST'])
def register():
 if GOOGLE_FORMS['registration']:
  return render_template('form_redirect.html',title='Student registration',description='Registration is handled securely by our Google Form.',form_url=GOOGLE_FORMS['registration'])
 if request.method=='POST':
  name=request.form.get('full_name','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
  if not name or len(name)>120 or '@' not in email or len(password)<8: flash('Enter your name, a valid email, and a password of at least 8 characters.','error')
  else:
   data=load_store()
   if any(u['email']==email for u in data['users']): flash('An account with this email already exists.','error')
   else:
    user={'id':uuid.uuid4().hex,'full_name':name,'email':email,'password_hash':generate_password_hash(password),'role':'student','profile_picture':None,'created_at':now()}
    data['users'].append(user); save_store(data); session['user_id']=user['id']; session['user_name']=name
    log_event('student_registered',{'name':name,'email':email,'user_id':user['id']}); flash('Welcome to BIGA HOME ACADEMY!','success'); return redirect(url_for('dashboard'))
 return render_template('auth.html',mode='register')
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
  user=next((u for u in load_store()['users'] if u['email']==email),None)
  if user and check_password_hash(user['password_hash'],password): session.clear(); session['user_id']=user['id']; session['user_name']=user['full_name']; flash('You are signed in.','success'); return redirect(request.args.get('next') or url_for('dashboard'))
  flash('Incorrect email or password.','error')
 return render_template('auth.html',mode='login')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('index'))
@app.route('/course/<course_id>')
def course_detail(course_id):
 c=get_course(course_id)
 if not c: abort(404)
 user=current_user(); data=load_store()
 lessons=[l for l in data['lessons'] if l['course_id']==course_id and l.get('published',True)]
 return render_template('course.html',course=c,lessons=lessons,is_enrolled=bool(user and enrolled(user['id'],course_id)))
@app.route('/enroll/<course_id>',methods=['POST'])
def enroll(course_id):
 c=get_course(course_id)
 if not c: abort(404)
 u=current_user()
 if not u:
  if GOOGLE_FORMS['enrollment']: return redirect(GOOGLE_FORMS['enrollment'])
  flash('Please register or sign in to enroll.','info'); return redirect(url_for('register'))
 if not enrolled(u['id'],course_id):
  d=load_store(); d['enrollments'].append({'id':uuid.uuid4().hex,'user_id':u['id'],'course_id':course_id,'created_at':now()}); save_store(d); log_event('course_enrolled',{'user_id':u['id'],'email':u['email'],'course_id':course_id,'course_title':c['title']}); flash('You are enrolled in '+c['title']+'.','success')
 return redirect(url_for('dashboard'))
@app.route('/dashboard')
@login_required
def dashboard():
 u=current_user(); d=load_store(); enrollments=[e for e in d['enrollments'] if e['user_id']==u['id']]
 rows=[]
 for e in enrollments:
  c=get_course(e['course_id'])
  if c:
   lessons=[l for l in d['lessons'] if l['course_id']==c['id'] and l.get('published',True)]
   done=sum(1 for l in lessons if any(p['user_id']==u['id'] and p['lesson_id']==l['id'] for p in d['progress']))
   rows.append({'course':c,'total':len(lessons),'done':done,'percent':int(done*100/len(lessons)) if lessons else 0})
 return render_template('dashboard.html',user=u,enrollments=rows,submissions=[s for s in d['submissions'] if s['user_id']==u['id']])
@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
 u=current_user(); d=load_store()
 if request.method=='POST':
  action=request.form.get('action','update'); name=request.form.get('full_name','').strip()
  if action=='remove_picture':
   old=u.get('profile_picture'); u['profile_picture']=None
   if old: (PROFILE_DIR/old).unlink(missing_ok=True)
  else:
   if not name or len(name)>120: flash('Enter a name between 1 and 120 characters.','error'); return render_template('profile.html',user=u)
   u['full_name']=name; session['user_name']=name
   f=request.files.get('profile_picture')
   if f and f.filename:
    try:
     img=Image.open(f.stream); img.verify(); f.stream.seek(0); img=Image.open(f.stream)
     if img.format not in ('JPEG','PNG','WEBP'): raise ValueError()
     img=img.convert('RGB'); img.thumbnail((600,600)); filename=uuid.uuid4().hex+'.jpg'; img.save(PROFILE_DIR/filename,'JPEG',quality=88,optimize=True)
     if u.get('profile_picture'): (PROFILE_DIR/u['profile_picture']).unlink(missing_ok=True)
     u['profile_picture']=filename
    except (UnidentifiedImageError,OSError,ValueError): flash('Upload a valid JPG, PNG, or WEBP image.','error'); return render_template('profile.html',user=u)
  save_store(d); flash('Profile updated.','success'); return redirect(url_for('profile'))
 return render_template('profile.html',user=u)
@app.route('/lesson/<lesson_id>')
@login_required
def lesson(lesson_id):
 d=load_store(); l=next((x for x in d['lessons'] if x['id']==lesson_id and x.get('published',True)),None)
 if not l: abort(404)
 u=current_user()
 if not enrolled(u['id'],l['course_id']) and u['role'] not in ('admin','instructor'): abort(403)
 done=any(p['user_id']==u['id'] and p['lesson_id']==lesson_id for p in d['progress'])
 lesson_materials=[m for m in d['materials'] if m.get('course_id')==l['course_id'] and m.get('published',True)]
 return render_template('lesson.html',lesson=l,course=get_course(l['course_id']),done=done,lesson_materials=lesson_materials)
@app.route('/lesson/<lesson_id>/complete',methods=['POST'])
@login_required
def complete_lesson(lesson_id):
 d=load_store(); l=next((x for x in d['lessons'] if x['id']==lesson_id),None); u=current_user()
 if not l: abort(404)
 if not enrolled(u['id'],l['course_id']) and u['role'] not in ('admin','instructor'): abort(403)
 if not any(p['user_id']==u['id'] and p['lesson_id']==lesson_id for p in d['progress']): d['progress'].append({'user_id':u['id'],'lesson_id':lesson_id,'completed_at':now()}); save_store(d); log_event('lesson_completed',{'user_id':u['id'],'email':u['email'],'lesson_id':lesson_id,'course_id':l['course_id']})
 flash('Lesson marked complete.','success'); return redirect(url_for('lesson',lesson_id=lesson_id))
@app.route('/assignments')
@login_required
def assignments():
 d=load_store(); u=current_user(); items=[dict(a,course_title=(get_course(a['course_id']) or {}).get('title','Course')) for a in d['assignments'] if a.get('published',True) and (enrolled(u['id'],a['course_id']) or u['role'] in ('admin','instructor'))]
 return render_template('assignments.html',assignments=items,submissions=[s for s in d['submissions'] if s['user_id']==u['id']])
@app.route('/assignment/<assignment_id>/submit',methods=['GET','POST'])
@login_required
def submit_assignment(assignment_id):
 d=load_store(); a=next((x for x in d['assignments'] if x['id']==assignment_id),None); u=current_user()
 if not a: abort(404)
 if not enrolled(u['id'],a['course_id']) and u['role'] not in ('admin','instructor'): abort(403)
 if GOOGLE_FORMS['assignment'] and request.method=='GET': return render_template('form_redirect.html',title='Submit assignment',description='Use the academy Google Form to submit your work. Include this assignment code in the form.',form_url=GOOGLE_FORMS['assignment'],reference=assignment_id)
 if request.method=='POST':
  text_answer=request.form.get('answer','').strip(); f=request.files.get('attachment'); attachment=None
  if f and f.filename:
   ext=Path(f.filename).suffix.lower()
   if ext not in {'.pdf','.doc','.docx','.ppt','.pptx','.txt','.zip'}: flash('Unsupported file type.','error'); return redirect(url_for('submit_assignment',assignment_id=assignment_id))
   attachment=uuid.uuid4().hex+ext; f.save(MATERIAL_DIR/attachment)
  if not text_answer and not attachment: flash('Add an answer or attach a file.','error'); return redirect(url_for('submit_assignment',assignment_id=assignment_id))
  item={'id':uuid.uuid4().hex,'assignment_id':assignment_id,'user_id':u['id'],'student_name':u['full_name'],'email':u['email'],'answer':text_answer,'attachment':attachment,'submitted_at':now(),'grade':None,'feedback':''}
  d['submissions'].append(item); save_store(d); log_event('assignment_submitted',{'submission_id':item['id'],'assignment_id':assignment_id,'student_name':u['full_name'],'email':u['email']}); flash('Assignment submitted.','success'); return redirect(url_for('assignments'))
 return render_template('assignment_form.html',assignment=a)
@app.route('/admin')
@role_required('admin','instructor')
def admin():
 d=load_store(); u=current_user(); staff=u['role'] in ('admin','instructor')
 return render_template('admin.html',courses=COURSES,lessons=d['lessons'],assignments=d['assignments'],materials=d['materials'],users=d['users'] if u['role']=='admin' else [],submissions=d['submissions'],is_admin=u['role']=='admin')
@app.route('/admin/lesson',methods=['POST'])
@role_required('admin','instructor')
def create_lesson():
 title=request.form.get('title','').strip(); cid=request.form.get('course_id',''); content=request.form.get('content','').strip(); video=request.form.get('video_url','').strip()
 if not title or not get_course(cid) or not content: flash('Title, course and lesson content are required.','error'); return redirect(url_for('admin'))
 d=load_store(); l={'id':uuid.uuid4().hex,'title':title,'course_id':cid,'content':content,'video_url':video,'published':True,'created_at':now(),'created_by':session['user_id']}; d['lessons'].append(l); save_store(d); log_event('lesson_published',{'lesson_id':l['id'],'title':title,'course_id':cid}); flash('Lesson published.','success'); return redirect(url_for('admin'))
@app.route('/admin/material',methods=['POST'])
@role_required('admin','instructor')
def upload_material():
 title=request.form.get('title','').strip(); cid=request.form.get('course_id',''); kind=request.form.get('kind','notes'); description=request.form.get('description','').strip(); external_url=request.form.get('external_url','').strip(); file=request.files.get('material_file')
 if not title or len(title)>160 or not get_course(cid) or kind not in ('notes','video'):
  flash('Enter a title, valid course and material type.','error'); return redirect(url_for('admin'))
 filename=None; original_name=None
 if file and file.filename:
  original_name=safe_file_name(file.filename)
  if not original_name or not is_allowed_material(original_name,kind):
   flash('Unsupported file type for this material. Check the allowed formats shown on the form.','error'); return redirect(url_for('admin'))
  filename=uuid.uuid4().hex+Path(original_name).suffix.lower()
  try: file.save(MATERIAL_DIR/filename)
  except OSError: flash('Could not save the uploaded file. Check folder permissions and available disk space.','error'); return redirect(url_for('admin'))
 if not filename and not external_url:
  flash('Choose a file to upload or provide a YouTube/Drive link.','error'); return redirect(url_for('admin'))
 if external_url and not external_url.startswith(('https://','http://')):
  if filename: (MATERIAL_DIR/filename).unlink(missing_ok=True)
  flash('External links must start with http:// or https://.','error'); return redirect(url_for('admin'))
 item={'id':uuid.uuid4().hex,'title':title,'course_id':cid,'kind':kind,'description':description,'filename':filename,'original_name':original_name,'external_url':external_url,'published':True,'created_at':now(),'created_by':session['user_id']}
 d=load_store(); d['materials'].append(item); save_store(d)
 log_event('course_material_published',{'material_id':item['id'],'title':title,'course_id':cid,'kind':kind,'has_file':bool(filename),'has_external_url':bool(external_url)})
 flash('Learning material published successfully.','success'); return redirect(url_for('admin'))

@app.route('/material/<material_id>/open')
@login_required
def open_material(material_id):
 d=load_store(); item=next((m for m in d['materials'] if m['id']==material_id and m.get('published',True)),None)
 if not item: abort(404)
 u=current_user()
 if not can_access_course_material(u,item['course_id']): abort(403)
 if item.get('external_url'): return redirect(item['external_url'])
 if not item.get('filename') or not (MATERIAL_DIR/item['filename']).is_file(): abort(404)
 return send_from_directory(MATERIAL_DIR,item['filename'],as_attachment=(item.get('kind')!='video'),download_name=item.get('original_name') or item['filename'])

@app.route('/material/<material_id>/delete',methods=['POST'])
@role_required('admin','instructor')
def delete_material(material_id):
 d=load_store(); item=next((m for m in d['materials'] if m['id']==material_id),None)
 if not item: abort(404)
 if item.get('filename'): (MATERIAL_DIR/item['filename']).unlink(missing_ok=True)
 d['materials']=[m for m in d['materials'] if m['id']!=material_id]; save_store(d)
 log_event('course_material_deleted',{'material_id':material_id,'course_id':item['course_id']})
 flash('Material removed.','success'); return redirect(url_for('admin'))

@app.route('/admin/assignment',methods=['POST'])
@role_required('admin','instructor')
def create_assignment():
 title=request.form.get('title','').strip(); cid=request.form.get('course_id',''); instructions=request.form.get('instructions','').strip()
 if not title or not get_course(cid) or not instructions: flash('Complete all assignment fields.','error'); return redirect(url_for('admin'))
 d=load_store(); a={'id':uuid.uuid4().hex,'title':title,'course_id':cid,'instructions':instructions,'published':True,'created_at':now()}; d['assignments'].append(a); save_store(d); log_event('assignment_published',{'assignment_id':a['id'],'title':title,'course_id':cid}); flash('Assignment published.','success'); return redirect(url_for('admin'))
@app.route('/admin/grade/<submission_id>',methods=['POST'])
@role_required('admin','instructor')
def grade_submission(submission_id):
 d=load_store(); s=next((x for x in d['submissions'] if x['id']==submission_id),None)
 if not s: abort(404)
 try: grade=float(request.form.get('grade',''))
 except ValueError: flash('Enter a numeric grade.','error'); return redirect(url_for('admin'))
 if not 0<=grade<=100: flash('Grade must be between 0 and 100.','error'); return redirect(url_for('admin'))
 s['grade']=grade; s['feedback']=request.form.get('feedback','').strip(); s['graded_at']=now(); save_store(d); log_event('assignment_graded',{'submission_id':s['id'],'student_email':s['email'],'grade':grade,'feedback':s['feedback']}); flash('Grade saved.','success'); return redirect(url_for('admin'))
@app.route('/contact')
def contact():
 if GOOGLE_FORMS['contact']: return redirect(GOOGLE_FORMS['contact'])
 return render_template('form_redirect.html',title='Contact BIGA HOME ACADEMY',description='The contact form is not configured yet. See README.md to connect your Google Form.',form_url='')
@app.route('/verify/<certificate_id>')
def verify_certificate(certificate_id):
 d=load_store(); cert=next((c for c in d['certificates'] if hmac.compare_digest(c['id'],certificate_id)),None)
 return render_template('verify_certificate.html',certificate=cert)
@app.route('/health')
def health(): return {'status':'ok','storage':'local-json','sql_enabled':False,'google_sheets_configured':bool(SHEETS_WEBHOOK)}
@app.errorhandler(403)
def forbidden(e): return render_template('403.html'),403
@app.errorhandler(404)
def not_found(e): return render_template('404.html'),404
if __name__=='__main__':
 print('BIGA HOME ACADEMY V7 — SQL-free mode with instructor content uploads. Configure Google Forms and Sheets in .env.')
 app.run(host=os.getenv('HOST','127.0.0.1'),port=int(os.getenv('PORT','5000')),debug=os.getenv('FLASK_DEBUG','0')=='1')
