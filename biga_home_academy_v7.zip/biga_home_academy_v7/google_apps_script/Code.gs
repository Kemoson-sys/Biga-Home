/**
 * BIGA HOME ACADEMY V6 -> Google Sheets event mirror.
 * Deploy as a Web App: Execute as Me; access Anyone (or restrict access and
 * use an authenticated gateway if your organisation requires it).
 * Set SCRIPT_SHARED_SECRET to the same value as GOOGLE_APPS_SCRIPT_SHARED_SECRET.
 */
const SPREADSHEET_ID = 'PASTE_GOOGLE_SHEET_ID_HERE';
const SCRIPT_SHARED_SECRET = 'REPLACE_WITH_A_LONG_RANDOM_SECRET';
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!SCRIPT_SHARED_SECRET || body.secret !== SCRIPT_SHARED_SECRET) {
      return json_({ ok: false, error: 'unauthorized' });
    }
    if (!SPREADSHEET_ID || SPREADSHEET_ID.indexOf('PASTE_') === 0) {
      return json_({ ok: false, error: 'configure_spreadsheet_id' });
    }
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = ss.getSheetByName('Academy Events');
    if (!sheet) {
      sheet = ss.insertSheet('Academy Events');
      sheet.appendRow(['Timestamp', 'Event', 'Payload JSON']);
    }
    sheet.appendRow([body.created_at || new Date().toISOString(), body.event || 'unknown', JSON.stringify(body.payload || {})]);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
