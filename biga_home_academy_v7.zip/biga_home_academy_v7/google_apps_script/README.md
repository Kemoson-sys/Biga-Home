# Google Sheets event mirror setup

1. Create a Google Sheet named `BIGA HOME ACADEMY Records`.
2. Copy its spreadsheet ID from the URL (`/spreadsheets/d/THIS_PART/edit`).
3. Open **Extensions → Apps Script**, paste `Code.gs`, set `SPREADSHEET_ID` and `SCRIPT_SHARED_SECRET`.
4. Choose **Deploy → New deployment → Web app**. Execute as **Me**. Set access according to your Google Workspace policy; a publicly reachable web app is required for this simple webhook, so use a long secret and do not store passwords or sensitive data in event payloads.
5. Copy the deployment URL ending in `/exec` to `GOOGLE_APPS_SCRIPT_WEB_APP_URL` in `.env`. Set `GOOGLE_APPS_SCRIPT_SHARED_SECRET` to the same secret.
6. Re-deploy after code changes. Check the `Academy Events` tab after testing a new registration or enrollment.

The app remains usable if Sheets is not configured. The local JSON file is the primary application store; the webhook mirrors selected events into Sheets. This is not two-way sync and Google Form responses do not automatically create app accounts.
