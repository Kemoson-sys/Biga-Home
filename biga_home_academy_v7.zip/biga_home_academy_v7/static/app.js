document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle'); const nav=document.querySelector('.nav');
 if(toggle&&nav) toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
 const year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
 document.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(btn.dataset.copy);const old=btn.textContent;btn.textContent='Copied!';setTimeout(()=>btn.textContent=old,1400);}catch(e){window.prompt('Copy this reference code:',btn.dataset.copy);}}));
});
