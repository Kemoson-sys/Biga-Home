# Google Forms setup (Version 6)

The project deliberately contains clearly marked empty URL settings because no Google Forms were supplied or created for you. Create these forms in your own Google account, set the response destination to a Google Sheet, then paste each published responder URL into `.env`.

## Form A — Student registration
Suggested fields: Full name (required), email (required), phone (optional), course interest (dropdown), learning goals (optional), consent to academy privacy notice (required).

**Security note:** Do not ask for passwords in Google Forms. Google Forms registration collects enquiries; it does not automatically create an authenticated account in this application. Until you build a trusted approval/import workflow, leave `GOOGLE_FORM_REGISTRATION_URL` blank to use the app's local account registration.

## Form B — Course enrollment
Suggested fields: Full name, email, course (dropdown matching academy courses), preferred learning mode, comments. Set responses to a dedicated Google Sheet. The app can link to this form for prospective enrollment, but form submissions do not automatically grant app access.

## Form C — Assignment submission
Suggested fields: Student full name, student email, course, assignment code, answer text, external file link (if needed), submission date. Google Forms file uploads usually require the respondent to sign in to Google. If using the app's built-in submission flow, leave `GOOGLE_FORM_ASSIGNMENT_URL` blank.

## Form D — Contact / feedback
Suggested fields: Name, email, subject, message, consent to be contacted.

## How to connect each form
1. Open Google Forms and create a form.
2. Open **Responses → Link to Sheets** to save responses in a Google spreadsheet.
3. Use **Publish/Send → Copy responder link** (not the editor link).
4. Paste the responder URL into the matching `.env` variable and restart Flask.
5. Test with a non-sensitive sample response and verify it appears in the expected Sheet.

Form links are optional. If a URL is blank, the corresponding built-in app workflow remains available where implemented.
