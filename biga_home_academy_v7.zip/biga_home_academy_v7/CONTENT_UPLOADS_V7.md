# Version 7 — Instructor Content Manager

## What changed
- Instructors/admins can upload course notes and videos from Manage academy.
- Files are linked to a selected course and listed on course and lesson pages for enrolled students.
- Supported notes: PDF, DOC, DOCX, PPT, PPTX, TXT, ZIP, CSV.
- Supported video files: MP4, WEBM, MOV.
- External YouTube/Google Drive links are supported.
- Materials can be removed from Manage academy; associated local files are deleted too.
- SQL remains removed. Metadata is saved in `data/academy.json`; uploaded files are in `static/uploads/materials/`.

## Upload instructions
1. Sign in as admin or instructor.
2. Open **Manage academy**.
3. Fill in the upload form and select a course.
4. Choose a file or provide an external URL, then publish.
5. Enrolled students open the course page to access the resources.

## Limits and security
- Flask request size limit: 250 MB per request. Host/proxy limits may be lower.
- For videos larger than this, use a trusted video hosting service.
- Do not upload copyrighted material without permission.
- Before public deployment, use HTTPS, a production WSGI server, file scanning, regular backups, and cloud/object storage appropriate for your traffic.
- Local JSON storage is a small prototype and can be unsafe with multiple concurrent workers.
